import org.junit.Test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import static org.junit.Assert.*;

public class MazeSolverTest {
    /*
    TODO - write JUnit tests testing the boards we gave you on the assignment
     */
    @Test

    public void mazeTest() throws IOException {



        assertTrue(MazeSolver.solve("C:\\Users\\Elizabeth\\Documents\\C343Labs\\HW1\\maze1.txt"));

        assertTrue(MazeSolver.solve("C:\\Users\\Elizabeth\\Documents\\C343Labs\\HW1\\maze2.txt"));

        assertFalse(MazeSolver.solve("C:\\Users\\Elizabeth\\Documents\\C343Labs\\HW1\\maze3.txt"));
    }


}
