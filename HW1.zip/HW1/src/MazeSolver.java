import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class MazeSolver {
    static char[][] maze;
    static int m, n; // dimensions of the maze; row and col

    public MazeSolver(int col, int row) {
        maze = new char[row][col];
        m = col;
        n = row;
    }

    /*
    TODO: setMaze - sets up the board
    This method will take in a String, file, which is the path of the file we want to look at.
    Using BufferedReader and FileReader, write this method so that it sets the rows, m, and columns, n,
    to the first line of input. Then it fills the maze with the maze from the file.
     */
    public static void setMaze(String file) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line = reader.readLine(); //reads first line with dimensions
        m = line.charAt(0);
        n = line.charAt(2);

        maze = new char[m][n];
        int row = 0; //temp number to check rows

        line = reader.readLine(); //read next line

        try {

            while (line != null) { //while line isn't empty

                for (int i = 0; i < line.length(); i++) { //goes through each character in a line
                    if (line.charAt(i) == 'S') {
                        maze[row][i] = 'S';
                    }
                    else if (line.charAt(i) == 'G') {
                        maze[row][i] = 'G';
                    }
                    else if (line.charAt(i) == '#') {
                        maze[row][i] = '#';
                    }
                    else if (line.charAt(i) == '.') {
                        maze[row][i] = '.';
                    }
                }
                row++; //row increases
                line = reader.readLine(); //reads next line
            }
            reader.close();

        }catch(IOException e){
            e.printStackTrace();

        }
    }

    /*
    TODO: isValid - checks if a position on the board has not been visited and is within bounds
     */
    public static boolean isValid(int x, int y) {
        if (maze[x][y] == '#') {
            return false; //not valid
        }
        else {
            return true; //valid, can go
        }
    }

    /*
    TODO: solveMaze - recursive function which will traverse the maze and find whether it's solveable S -> G
    The input is the index that we want to check: x = row, y = column
    ------ Hint -------
    Cell(i,j) -> if it’s a wall return false
    Cell(i,j) is ‘G’ return true
    Otherwise, mark cell(i,j) as visited (maybe make it a wall) and
    return if you can find a way out from the top, bottom, left, or right…
     */
    public static boolean solveMaze(int x, int y) {
        boolean answer = false;
        // modify
        //BASE CASES:

        if (maze[x][y] == 'G') { //if made it to end, return true;
            return true;
        }
        else if (maze[x][y] == '#') { //if you hit a wall, return false
            return false;
        }
        else { //recursion
            maze[x][y] = '#'; //turn current cell to a wall; already visited
            if (isValid(x-1, y)) { //if it's on the left
                answer = solveMaze(x-1, y);
            }
            if (isValid(x+1, y)) { //if it's on the right
                answer = solveMaze(x+1, y);
            }
            if (isValid(x, y-1)) { //if it's on top
                answer = solveMaze(x, y-1);
            }
            if (isValid(x, y+1)) { //if it's on bottom
                answer = solveMaze(x, y+1);
            }
            return answer; //not sure if it helps with multiple recursion conditions, but I hope so

        }

    }

    /*
    TODO: solve - sets the maze up, solves the board, print whether it can be solved or not, returns whether its solvable or not
     */
    public static boolean solve(String file) throws IOException {
        //modify
        FileReader file1 = new FileReader(file);
        BufferedReader reader = new BufferedReader(file1);
        String line = reader.readLine(); //reads first line with dimensions

        int sCol = 0;
        int sRow = 0;

        while (line != null) {
            setMaze(line); //sets up maze
            line = reader.readLine(); //reads line below current
        }


        for (int i = 0; i < line.length(); i++) { //need to find 'S' in second row
            if (line.charAt(i) == 'S') {
                sCol = i;
            }
        }


        boolean solved = solveMaze(sRow, sCol);

        return solved;
    }

    public static void main(String args[]) throws IOException {
            BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\Elizabeth\\Documents\\C343Labs\\HW1\\maze1.txt"));

            String line = reader.readLine();

            while (line != null) {

            }
    }


}